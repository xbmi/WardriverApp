/** Automatically generated file. DO NOT MODIFY */
package com.inf8405.wardriver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}